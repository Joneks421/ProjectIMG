old_info = {'n': {'left': left, 'message': message, 'timestamp': timestamp,
                                      'top': top}}