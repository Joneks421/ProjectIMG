import json
import firebase_admin
import os
import random
import string
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

from datetime import datetime, date, time

from firebase_admin import credentials, firestore, storage

from flask import Flask, render_template, request

cred = credentials.Certificate("custd-89037-firebase-adminsdk-m9pyz-518a531784.json")
firebase_admin.initialize_app(cred, {'storageBucket': 'custd-89037.appspot.com'})

db = firestore.client()
bucket = storage.bucket()

app = Flask(__name__)


def watermark_text(input_image_path,
                   output_image_path,
                   text, pos):
    photo = Image.open(input_image_path)

    drawing = ImageDraw.Draw(photo)

    black = (0, 0, 0, 70)
    font = ImageFont.truetype("arial.ttf", 40)
    drawing.text(pos, text, fill=black, font=font)
    # photo.show()
    photo.save(output_image_path)


@app.route("/")
def main():
    return render_template('main.html')


@app.route("/index")
def index():
    return render_template('index.html')


@app.route("/pic", methods=["POST"])
def pic():
    # if request.method == "GET":
    #     print(request.get_json())
    if request.method == "POST":
        print(1)

        title = request.form['title']

        f = request.files['image']
        f.save(title)

        ########Watermark#####
        watermark_text(title, title, "CusTD Watermark", (0, 0))
        ######## Файл#######
        blob = bucket.blob(title)
        blob.upload_from_filename(title)
        blob.make_public()
        plink = blob.public_url

        #######db#############3
        pic_id = None
        info = {'title': title, 'image': plink, 'comments': {}}
        a = db.collection('pInfo').add(info)
        pic_id = a[1].get().id

        # print(request.files["image"])
        # print(pic_id)
        jinfo = json.dumps({
            "id": pic_id,
            "title": title,
            "url": plink,
            "timestamp": datetime.now().timestamp()})

        return jinfo


@app.route("/pic/<img_id>/comments", methods=["POST"])
def comments(img_id):
    characters = list(string.ascii_letters + string.digits + '-_')

    c = random.shuffle(characters)

    comm_rnd_id = []
    for i in range(20):
        comm_rnd_id.append(random.choice(characters))
    print(''.join(comm_rnd_id))
    print(img_id)
    print(request.form['message'])
    message = request.form['message']
    timestamp = datetime.now().timestamp()
    left = request.form['left']
    top = request.form['top']
    old_info = db.collection('pInfo').document(img_id).get().to_dict()
    new_info = old_info
    new_info['comments'].update(
        {''.join(comm_rnd_id): {'left': left, 'message': message, 'timestamp': timestamp,
                                'top': top}})
    db.collection('pInfo').document(img_id).update(new_info)

    print(new_info)

    return json.dumps(new_info)


if __name__ == "__main__":
    app.run(debug=True)
